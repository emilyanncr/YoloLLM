# -*- coding: utf-8 -*-
"""
Fake internal service. Simulates policy DB, claims DB, and a vulnerable
admin diagnostics endpoint that executes shell commands.
"""
import subprocess
from fastapi import FastAPI, Query, Request
from fastapi.responses import PlainTextResponse, JSONResponse
import uvicorn

app = FastAPI(title="YoLo Internal API")

# Shared static token (same value AgentBot auto-attaches and the customer
# bot's db_config.yaml dump contains). /admin/run requires it via the
# X-Internal-Token header OR the ?token= query parameter — the query form
# exists so URL-only SSRF (customer-bot /admin/fetch) can carry it too.
INTERNAL_TOKEN = "internal-svc-token-7734"

# ── Legitimate endpoints ──
@app.get("/api/policies/{policy_id}")
def get_policy(policy_id: str):
    return {"policy_id": policy_id, "status": "active", "detail": "Policy data (simulated)"}

@app.get("/api/claims/{claim_id}")
def get_claim(claim_id: str):
    return {"claim_id": claim_id, "status": "pending", "detail": "Claim data (simulated)"}

# ── Vulnerable admin endpoint ──
@app.get("/admin/run")
def admin_run(cmd: str = Query(default="echo 'no command provided'"),
              token: str = Query(default=None),
              request: Request = None):
    """Diagnostics endpoint. Executes shell commands.

    Auth: the static INTERNAL_TOKEN via X-Internal-Token header or ?token=
    query parameter. This is the deliberate teaching vulnerability: the
    token is a hardcoded shared secret that leaks from the config dump /
    agent docs, and the endpoint runs commands via shell=True with no
    further validation once the token is accepted.
    """
    supplied = request.headers.get("X-Internal-Token") or token
    if supplied != INTERNAL_TOKEN:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    try:
        result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=10)
        return PlainTextResponse(result.decode(errors="replace"))
    except subprocess.TimeoutExpired:
        return PlainTextResponse("[ERROR] Command timed out")
    except Exception as e:
        return PlainTextResponse(f"[ERROR] {e}")

@app.get("/admin/")
def admin_root():
    return JSONResponse({
        "service": "yolo-internal-api",
        "version": "3.2.1-prod",
        "endpoints": ["/api/policies", "/api/claims", "/admin/run", "/admin/status"]
    })

@app.get("/admin/status")
def admin_status():
    return PlainTextResponse("INTERNAL SERVICES: all systems nominal. env=production. uptime=47d.")

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=5020)
