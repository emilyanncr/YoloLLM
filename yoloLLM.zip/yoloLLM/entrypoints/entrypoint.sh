#!/usr/bin/env bash
set -euo pipefail

echo "[yolollm] booting all services ..."

# 1) Wait for the Ollama API (sidecar container, hostname "ollama")
until python3 -c "import urllib.request as u; u.urlopen('http://ollama:11434/api/tags', timeout=2)" 2>/dev/null; do
  echo "[yolollm] waiting for ollama API ..."
  sleep 2
done
echo "[yolollm] ollama API is up"

# 2) Wait for the model to finish pulling
python3 - <<'PY'
import json, os, time, urllib.request as u
model = os.environ.get("MODEL_NAME", "llama3.2:3b")
for _ in range(300):
    try:
        data = json.load(u.urlopen("http://ollama:11434/api/tags", timeout=2))
        if any(x.get("name") == model for x in data.get("models", [])):
            print(f"[yolollm] model '{model}' is ready")
            raise SystemExit(0)
    except SystemExit:
        raise
    except Exception:
        pass
    time.sleep(2)
print("[yolollm] ERROR: model never appeared after 10 minutes")
raise SystemExit(1)
PY

# 3) Make the fake AWS metadata service reachable at the real IMDS address
#    too (http://169.254.169.254:5030/latest/meta-data/...), like on EC2.
if ip addr add 169.254.169.254/32 dev lo 2>/dev/null; then
  echo "[yolollm] 169.254.169.254 assigned to loopback (IMDS-style SSRF works)"
else
  echo "[yolollm] WARNING: could not assign 169.254.169.254 (container lacks NET_ADMIN?) — metadata still reachable via http://127.0.0.1:5030"
fi

# 4) Launch every service. Each app runs from its own subdir so its
#    ./sensitive and ./<name>_chroma are seeded into the right place.
pids=()
start() {
  ( cd "$1" && shift && exec "$@" ) &
  pids+=($!)
}

echo "[yolollm] customer bot (yoloinsurance, non-agentic) on 0.0.0.0:5000"
start /app/yoloinsurance python3 -m uvicorn yoloinsurance:app --host 0.0.0.0 --port 5000

echo "[yolollm] agent bot (yoloAgent, agentic) on 0.0.0.0:5010"
start /app/yoloagent python3 -m uvicorn yoloAgent:app --host 0.0.0.0 --port 5010

# Internal API: policy DB / claims DB + vulnerable /admin/run (RCE).
# Loopback-only: reachable by the bots (and players via SSRF), not published.
echo "[yolollm] internal_service (RCE /admin/run) on 127.0.0.1:5020"
start /app/internal python3 -m uvicorn internal_service:app --host 127.0.0.1 --port 5020

# Fake AWS metadata (IMDS paths). 0.0.0.0 so it answers on BOTH 127.0.0.1
# and the 169.254.169.254 loopback alias. Not published to the host.
echo "[yolollm] AWS_metadata_svs on 0.0.0.0:5030 (127.0.0.1 + 169.254.169.254)"
start /app/metadata python3 -m uvicorn AWS_metadata_svs:app --host 0.0.0.0 --port 5030

# "YouOnlyLiveOnce" poisoned replica site (binds port 80 as root).
echo "[yolollm] YouOnlyLiveOnce replica site on 0.0.0.0:80 (published as :8080)"
start /app/youonlyliveonce python3 server.py

cleanup() {
  echo "[yolollm] shutting down ..."
  kill "${pids[@]}" 2>/dev/null || true
}
trap cleanup INT TERM EXIT

# Die if any service crashes; keep the container alive otherwise.
while :; do
  wait -n || true
  for p in "${pids[@]}"; do
    if ! kill -0 "$p" 2>/dev/null; then
      echo "[yolollm] ERROR: a service exited unexpectedly (pid ${p})"
      exit 1
    fi
  done
done
