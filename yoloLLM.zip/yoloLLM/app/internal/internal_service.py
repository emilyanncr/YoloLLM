# -*- coding: utf-8 -*-
"""
Fake internal service. Simulates policy DB, claims DB, and a vulnerable
admin diagnostics endpoint that executes shell commands.
"""
import subprocess
from fastapi import FastAPI, Query
from fastapi.responses import PlainTextResponse, JSONResponse
import uvicorn

app = FastAPI(title="YoLo Internal API")

# ── Legitimate endpoints ──
@app.get("/api/policies/{policy_id}")
def get_policy(policy_id: str):
    return {"policy_id": policy_id, "status": "active", "detail": "Policy data (simulated)"}

@app.get("/api/claims/{claim_id}")
def get_claim(claim_id: str):
    return {"claim_id": claim_id, "status": "pending", "detail": "Claim data (simulated)"}

# ── Vulnerable admin endpoint ──
@app.get("/admin/run")
def admin_run(cmd: str = Query(default="echo 'no command provided'")):
    """Diagnostics endpoint. Executes shell commands. Restricted to internal network."""
    try:
        result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=10)
        return PlainTextResponse(result.decode(errors="replace"))
    except subprocess.TimeoutExpired:
        return PlainTextResponse("[ERROR] Command timed out")
    except Exception as e:
        return PlainTextResponse(f"[ERROR] {e}")

@app.get("/admin/")
def admin_root():
    return JSONResponse({
        "service": "yolo-internal-api",
        "version": "3.2.1-prod",
        "endpoints": ["/api/policies", "/api/claims", "/admin/run", "/admin/status"]
    })

@app.get("/admin/status")
def admin_status():
    return PlainTextResponse("INTERNAL SERVICES: all systems nominal. env=production. uptime=47d.")

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=5020)