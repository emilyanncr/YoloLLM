# fake_internal.py — Fake AWS metadata + internal services for SSRF demo
from fastapi import FastAPI
from fastapi.responses import PlainTextResponse, JSONResponse
import uvicorn

app = FastAPI(title="Internal Services Simulator")

# ── AWS IMDS-style paths ─────────────────────────────────

@app.get("/latest/meta-data/", response_class=PlainTextResponse)
def meta_root():
    return "ami-id\nhostname\niam/\ninstance-id\nlocal-ipv4\npublic-ipv4\n"

@app.get("/latest/meta-data/ami-id", response_class=PlainTextResponse)
def ami_id():
    return "ami-0yolobotprod2026"

@app.get("/latest/meta-data/hostname", response_class=PlainTextResponse)
def hostname():
    return "yolobot-prod-i-0a1b2c3d.ec2.internal"

@app.get("/latest/meta-data/instance-id", response_class=PlainTextResponse)
def instance_id():
    return "i-0a1b2c3dyolobot"

@app.get("/latest/meta-data/local-ipv4", response_class=PlainTextResponse)
def local_ip():
    return "10.0.12.47"

@app.get("/latest/meta-data/public-ipv4", response_class=PlainTextResponse)
def public_ip():
    return "203.0.113.50"

@app.get("/latest/meta-data/iam/", response_class=PlainTextResponse)
def iam_root():
    return "info\nsecurity-credentials/"

@app.get("/latest/meta-data/iam/security-credentials/", response_class=PlainTextResponse)
def iam_roles():
    return "YoLoBotProd"

@app.get("/latest/meta-data/iam/security-credentials/YoLoBotProd")
def iam_creds():
    return JSONResponse({
        "Code": "Success",
        "LastUpdated": "2026-07-23T12:00:00Z",
        "Type": "AWS-HMAC",
        "AccessKeyId": "ASIAYOLOBOTFAKEDEMO2026",
        "SecretAccessKey": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYYOLOBOTFAKE",
        "Token": "IQoJb3JpZ2luX2VjEExactFakeSessionTokenForYoLoBotProdDemo==",
        "Expiration": "2026-07-23T18:00:00Z"
    })

# ── Fake internal app endpoints (optional extras) ─────────

@app.get("/admin/status", response_class=PlainTextResponse)
def admin_status():
    return "INTERNAL ADMIN OK — role=superuser env=prod"

@app.get("/internal/config")
def internal_config():
    return {
        "service": "yolo-claims-api",
        "env": "production",
        "db_host": "db-primary.yoloinsurance.internal",
        "db_user": "prod_readwrite",
    }

if __name__ == "__main__":
    # Bind all interfaces: answers on 127.0.0.1 and (inside Docker) on the
    # 169.254.169.254 loopback alias; never published outside the container
    uvicorn.run(app, host="0.0.0.0", port=5030)