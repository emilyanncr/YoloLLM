#!/usr/bin/env python3
import http.server
import socketserver
import os

PORT = 80
DIRECTORY = os.path.dirname(os.path.abspath(__file__))

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def log_message(self, fmt, *args):
        print(f"[youOnlyLiveOnce.local] {self.address_string()} {fmt % args}")

try:
    with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
        print(f"Serving replica at http://youOnlyLiveOnce.local:{PORT}")
        httpd.serve_forever()
except PermissionError:
    PORT = 8080
    with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
        print("Port 80 needs root. Falling back to port 8080.")
        print(f"Serving replica at http://youOnlyLiveOnce.local:{PORT}")
        httpd.serve_forever()
